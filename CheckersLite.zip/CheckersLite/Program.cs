﻿using System;

namespace CheckersLite
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Checkers Lite!");
			
			GameController gameController = new GameController();
        }
    }
}
