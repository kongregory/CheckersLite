﻿using System;

namespace CheckersLite {
    public class LevelView {
        private LevelController m_levelController;

        public LevelView(LevelController levelController) {
            m_levelController = levelController;
        }

        public void DisplayLevel() {
            Console.WriteLine(GetLevelAscii());
        }

        public string GetLevelAscii() {
            string levelAscii = "";
            for (int i = 0; i < m_levelController.tiles.GetLength(1); i++) {
                levelAscii = GetRowAscii(i) + "\n" + levelAscii;
            }

            return levelAscii;
        }

        public string GetRowAscii(int rowIndex) {
            string rowAscii = "";
            for (int j = 0; j < m_levelController.tiles.GetLength(0); j++) {
                CharacterController characterController = m_levelController.tiles[j, rowIndex].characterController;
                if (characterController != null) {
                    if (characterController.m_playerID == 0) {
                        if (characterController.isKing)
                            rowAscii += "O";
                        else
                            rowAscii += "o";
                    }
                    else {
                        if (characterController.isKing)
                            rowAscii += "X";
                        else
                            rowAscii += "x";
                    }
                }
                else {
                    rowAscii += ".";
                }
            }

            return rowAscii;
        }

        public void DisplayGameState(LogicController.GameState gameState) {
            Console.WriteLine("GameState = " + gameState);
        }
    }
}