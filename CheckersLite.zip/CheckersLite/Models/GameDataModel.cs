﻿using System.Collections.Generic;

namespace CheckersLite {
    public class GameDataModel {
        public List<PlayerDataModel> playerDataModels = new List<PlayerDataModel>();

        public Vector2 grid { get; private set; }

        public List<Vector2> possibleAIMoves { get; private set; } = new List<Vector2>() {
        new Vector2(-1,-1),
        new Vector2(1, -1),
        new Vector2(-2,-2),
        new Vector2(2,-2),
    };

        public GameDataModel() {
            LoadGameData();
        }

        public void LoadGameData() {
            //NOTE: This can be modified to load data from a file e.g. JSON or from the backend.

            LoadPlayerData();

            grid = new Vector2(8, 8);
        }

        private void LoadPlayerData() {
			int numCharacters = 12;
			
            List<Vector2> player1Positions = new List<Vector2>() {
				new Vector2(0,0),
				new Vector2(2,0),
				new Vector2(4,0),
				new Vector2(6,0),

				new Vector2(1,1),
				new Vector2(3,1),
				new Vector2(5,1),
				new Vector2(7,1),

				new Vector2(0,2),
				new Vector2(2,2),
				new Vector2(4,2),
				new Vector2(6,2)
			};
            PlayerDataModel player1DataModel = new PlayerDataModel(0, false, numCharacters, player1Positions);
            playerDataModels.Add(player1DataModel);

            List<Vector2> player2Positions = new List<Vector2>() {
				new Vector2(1,5),
				new Vector2(3,5),
				new Vector2(5,5),
				new Vector2(7,5),

				new Vector2(0,6),
				new Vector2(2,6),
				new Vector2(4,6),
				new Vector2(6,6),

				new Vector2(1,7),
				new Vector2(3,7),
				new Vector2(5,7),
				new Vector2(7,7)
			};

            PlayerDataModel player2DataModel = new PlayerDataModel(1, true, numCharacters, player2Positions);
            playerDataModels.Add(player2DataModel);
        }
    }

    public class PlayerDataModel {
        public int playerID { get; private set; }
        public bool isAI { get; private set; }
        public int numCharacters { get; private set; } = 12;

        public List<Vector2> characterPositions { get; private set; } = new List<Vector2>();

        public PlayerDataModel(int playerID, bool isAI, int numCharacters, List<Vector2> characterPositions) {
            this.playerID = playerID;
            this.isAI = isAI;
            this.numCharacters = numCharacters;
            this.characterPositions = characterPositions;
        }
    }
}