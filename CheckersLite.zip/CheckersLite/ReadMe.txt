This is a version of Checkers Lite
By Greg Kon
Made to work with dotnet-3.0.102

Instructions to play.
Navigate to the project directory in command line.
E.g C:\Users\[YourUser]\CheckersLite
Run the command dotnet run
You should see the following message "Welcome to Checkers Lite!"
And an ascii representation of the checker board.
.x.x.x.x
x.x.x.x.
.x.x.x.x
........
........
o.o.o.o.
.o.o.o.o
o.o.o.o.

The grid coordinates start at the bottom left corner 0,0 and go to the top right 7,7.
You go first.
You need to input valid moves in the format x1,y1,x2,y2 regex [0-9],[0-9],[0-9],[0-9].
E.g. an opening move could be:
0,2,1,3
This means you want to move your character from (0,2) to (1,3)
If your input cannot be parsed you will get a message informing you to enter valid input.
There are checks to see if you entered the correct from and to positions.
There are checks to see if you have a character on the from position.
There are checks that request that you make a jump if there is a valid jump before you make a normal move.
You cannot move into a occupied tile.
If you jump over an enemy you kill them.
After each turn you get a GameState print.
After your turn the AI will move randomly.
If the AI makes an incorrect attempt it will print the MoveResponse and keep trying until it makes a legal move.
After the AI moves you will be able to input your move again.
This will continue until a player loses or there is a tie.
The objective is to kill all the enemy characters by jumping over them.

This implementation separates the data, controllers and views.
The main file is Program.cs which creates an instance of the GameController.
The gameController setups the other controllers, the view and the input.
The gameController also has the main update loop.
The game data is in a separte file.
The game logic is also in a separate file.

The advantage of this approach is that this way we can do the following things.
Extract logic to a server so that it is authoritative.
Swap the view with some nice gui.
Swap the input to be more user friendly.
Load the game data from a json file or a backend etc.
And most of the remaining game would not require much changes.

The system is design to be easy to change the board dimensions, number of characters, number of players and toggle AI.

There are a lot of ways to improve this game.
E.g. UI, Input, Saving the game state, proper AI that isn't random, logic for the King characters.

Overall I am happy with the results given the time constraint.

Thank you for playing!

