﻿using System;
using System.Collections.Generic;

namespace CheckersLite {
    public class GameController {
        private GameDataModel m_gameDataModel;
        private LevelController m_levelController;
        private LevelView m_levelView;
        private LogicController m_logicController;
		private InputController m_inputController;
		
        private int m_currentPlayerIndex = 0;

        public List<PlayerController> players { get; private set; } = new List<PlayerController>();

		private bool isLooping = true;
		
        public GameController() {
            m_gameDataModel = new GameDataModel();

            Initialize();
        }

        public void Initialize() {
            m_levelController = new LevelController(m_gameDataModel.grid);

            for (int i = 0; i < m_gameDataModel.playerDataModels.Count; i++) {
                PlayerController playerConroller = new PlayerController(m_gameDataModel.playerDataModels[i], m_levelController);
                players.Add(playerConroller);
            }

            m_logicController = new LogicController(this, m_levelController);

            m_levelView = new LevelView(m_levelController);
            m_levelView.DisplayLevel();
			
			m_inputController = new InputController(this);
			
			CustomUpdate();
        }

		private void CustomUpdate(){
			while(isLooping){
				m_inputController.TryGetInput();
			}
		}
		
        public bool ProcessTurn(Vector2 fromPosition, Vector2 toPosition) {
            LogicController.MoveResponse moveResponse = m_logicController.TryToPerformMove(m_currentPlayerIndex, fromPosition, toPosition);
            Console.WriteLine(fromPosition + " , " + toPosition + " , player= " + m_currentPlayerIndex + " MoveResponse: " + moveResponse);

            if (moveResponse == LogicController.MoveResponse.success) {
                LogicController.GameState gameState = m_logicController.CheckGameOver();
                m_levelView.DisplayGameState(gameState);

                ChangeCurrentPlayer();

                m_levelView.DisplayLevel();

                if (gameState == LogicController.GameState.playing){
					TryAIResponse();
				}
				else{
					isLooping = false;
				}
				
                return true;
            }

            return false;
        }

        public void ChangeCurrentPlayer() {
            //Cycle through the players starting from the first one. This supports more than two players.
            m_currentPlayerIndex++;
            m_currentPlayerIndex = m_currentPlayerIndex % m_gameDataModel.playerDataModels.Count;
        }

        public void TryAIResponse() {
            if (m_currentPlayerIndex == 1) {
                bool isAIActionSuccess = false;
                while (!isAIActionSuccess) {
                    System.Random random = new System.Random();
                    int randomCharacterIndex = random.Next(0, m_levelController.characters.Count);
                    CharacterController characterController = m_levelController.characters[randomCharacterIndex];

                    if (!m_gameDataModel.playerDataModels[m_currentPlayerIndex].isAI) {
                        continue; //not ai;
                    }

                    int randomMoveIndex = random.Next(0, 4);
                    Vector2 randomAIMove = m_gameDataModel.possibleAIMoves[randomMoveIndex];

                    Vector2 fromPos = characterController.m_position;

                    isAIActionSuccess = ProcessTurn(fromPos, new Vector2(fromPos.x + randomAIMove.x, fromPos.y + randomAIMove.y));
                }
            }
        }
    }
}