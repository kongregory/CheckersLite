﻿using System.Collections.Generic;

namespace CheckersLite {
    public class LogicController {
        private GameController m_gameController;
        private LevelController m_levelController;

        public enum GameState {
            playing = -1,
            playerID0Lost = 0,
            playerID1Lost = 1,
            tie = 2
        }

        public enum MoveResponse {
            success,
            invalidFromPosition,
            invalidToPosition,
            playerMustJumpBeforeMoving,
            invalidNormalMove,
            invalidJumpMove,
            noEnemyToJumpOver,
        }
        public LogicController(GameController gameController, LevelController levelController) {
            m_gameController = gameController;
            m_levelController = levelController;
        }

        public MoveResponse TryToPerformMove(int playerID, Vector2 fromPosition, Vector2 toPosition) {

            if (!IsFromPositionValid(playerID, fromPosition))
                return MoveResponse.invalidFromPosition;

            if (!IsToPositionValid(toPosition))
                return MoveResponse.invalidToPosition;

            if (!IsAttemptingJump(fromPosition, toPosition)) {
                if (CanPlayerJump(playerID)) { //If the player has the option to jump but is not attempting to jump this move is not valid because they must jump.
                    return MoveResponse.playerMustJumpBeforeMoving;
                }
                else { //the player is trying to move normally
                    bool isValidNormalMove = IsValidMove(playerID, fromPosition, toPosition, 1);
                    if (isValidNormalMove) {
                        //Do normal move
                        m_levelController.MoveCharacter(fromPosition, toPosition);
                        TryPromoteToKing(toPosition);
                        return MoveResponse.success;
                    }
                    else {
                        return MoveResponse.invalidNormalMove;
                    }
                }
            }
            else {
                //attempting to jump
                if (!IsValidMove(playerID, fromPosition, toPosition, 2))
                    return MoveResponse.invalidJumpMove;

                CharacterController enemyCharacterController = GetEnemyToJump(playerID, fromPosition, toPosition);
                if (enemyCharacterController == null)
                    return MoveResponse.noEnemyToJumpOver;

                //kill enemy character
                m_levelController.characters.Remove(enemyCharacterController);
                m_levelController.tiles[enemyCharacterController.m_position.x, enemyCharacterController.m_position.y].characterController = null;

                //Do jump
                m_levelController.MoveCharacter(fromPosition, toPosition);
                TryPromoteToKing(toPosition);
                return MoveResponse.success;
            }
        }

        private bool CanPlayerJump(int playerID) {
            //TODO: Check if there are any potential jumps that the player must do.
            List<CharacterController> playerCharacters = m_levelController.GetCharactersOfPlayer(playerID);
            if (playerCharacters == null || playerCharacters.Count < 1)
                return false;

            for(int i = 0; i< playerCharacters.Count; i++) {
                if (CanCharacterJump(playerID, playerCharacters[i]))
                    return true;
            }
            return false;
        }

        private bool CanCharacterJump(int playerID, CharacterController characterController) {
            int deltaY = 2; //jumping up
            if (playerID == 1) //jumping down
                deltaY = -2;

            Vector2 toPositionA = new Vector2(characterController.m_position.x - 2, characterController.m_position.y + deltaY);
            Vector2 toPositionB = new Vector2(characterController.m_position.x + 2, characterController.m_position.y + deltaY);

            if(IsToPositionValid(toPositionA) && GetEnemyToJump(playerID, characterController.m_position, toPositionA) != null) {
                return true;
            }

            if (IsToPositionValid(toPositionB) && GetEnemyToJump(playerID, characterController.m_position, toPositionB) != null) {
                return true;
            }

            return false;
        }

        private void TryPromoteToKing(Vector2 toPosition) {
            if (toPosition.y == 0 || toPosition.y == m_levelController.m_grid.y - 1) {
                CharacterController characterController = m_levelController.tiles[toPosition.x, toPosition.y].characterController;
                characterController.isKing = true;
                int characterIndex = m_levelController.characters.IndexOf(characterController);
                if (characterIndex >= 0) {
                    m_levelController.characters[characterIndex].isKing = true;
                }
            }
        }

        private bool IsValidMove(int playerID, Vector2 fromPosition, Vector2 toPosition, int distance) {
            Vector2 deltaPosition = new Vector2(toPosition.x - fromPosition.x, toPosition.y - fromPosition.y);
            if (deltaPosition.x == distance || deltaPosition.x == -distance) {
                if (playerID == 0 && deltaPosition.y == distance) {
                    return true;
                }
                if (playerID == 1 && deltaPosition.y == -distance) {
                    return true;
                }
            }

            return false;
        }

        private bool IsAttemptingJump(Vector2 fromPosition, Vector2 toPosition) {
            Vector2 deltaPosition = new Vector2(toPosition.x - fromPosition.x, toPosition.y - fromPosition.y);
            if (deltaPosition.x == 2 || deltaPosition.x == -2) {
                if (deltaPosition.y == 2 || deltaPosition.y == -2) {
                    return true;
                }
            }

            return false;
        }

        private CharacterController GetEnemyToJump(int playerID, Vector2 fromPosition, Vector2 toPosition) {
            Vector2 enemyPosition = new Vector2((fromPosition.x + toPosition.x) / 2, (fromPosition.y + toPosition.y) / 2);
            CharacterController enemyCharacterController = m_levelController.tiles[enemyPosition.x, enemyPosition.y].characterController;
            if (enemyCharacterController == null) { //this position doesn't have a enemy to jump over
                return null;
            }

            if (enemyCharacterController.m_playerID == playerID)
                return null; //can't jump over your own character

            return enemyCharacterController;
        }

        private bool IsFromPositionValid(int playerID, Vector2 position) {
            if (!IsPositionInBounds(position)) //this position is out of bounds
                return false;

            CharacterController targetCharacter = m_levelController.tiles[position.x, position.y].characterController;
            if (targetCharacter == null) { //this position doesn't have a character to target
                return false;
            }

            if (targetCharacter.m_playerID != playerID) //this player doesn't own the target character
                return false;

            return true;
        }

        private bool IsToPositionValid(Vector2 position) {
            if (!IsPositionInBounds(position)) //this position is out of bounds
                return false;

            CharacterController targetCharacter = m_levelController.tiles[position.x, position.y].characterController;
            if (targetCharacter != null) { //this position is occupied
                return false;
            }

            return true;
        }

        private bool IsPositionInBounds(Vector2 position) {
            if (position.x < 0 || position.x >= m_levelController.m_grid.x || position.y < 0 || position.y >= m_levelController.m_grid.y) //position out of bounds
                return false;
            return true;
        }

        public GameState CheckGameOver() {
            List<bool> playersLost = new List<bool>();
            for(int i = 0; i< m_gameController.players.Count; i++) {
                bool isPlayerLost = true;
                List<CharacterController> characters = m_levelController.GetCharactersOfPlayer(m_gameController.players[i].m_playerDataModel.playerID);
                for(int j = 0; j < characters.Count; j++) {
                    if (characters[j].isKing)
                        continue;

                    isPlayerLost = false; //player has a non king character so they didn't lose yet. //TODO: Also check for valid moves
                }

                playersLost.Add(isPlayerLost);
            }

            if (DidEveryoneLose(playersLost)) {
                //tie, this can happen if a checker kills another one and is prompted to king which is currently not supported.
                return GameState.tie;
            }
            else if (playersLost[0]) {
                return GameState.playerID0Lost;
            }
            else if (playersLost[1]) {
                return GameState.playerID1Lost;
            }
            else {
                return GameState.playing;
            }
        }

        private bool DidEveryoneLose(List<bool> playersLost) {
            for (int i = 0; i < playersLost.Count; i++) {
                if (!playersLost[i])
                    return false;
            }

            return true;
        }
    }
}