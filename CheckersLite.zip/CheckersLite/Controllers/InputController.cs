﻿using System;
using System.Text.RegularExpressions;

namespace CheckersLite {
    public class InputController {
		private GameController m_gameController;
		
        private string m_inputString = "";
        private const string c_inputPattern = "[0-9],[0-9],[0-9],[0-9]";

        private Vector2 m_fromPostion;
        private Vector2 m_toPosition;

		public InputController(GameController gameController){
			m_gameController = gameController;
		}
		
		public void TryGetInput(){
			Console.WriteLine("Please input your move in the format x1,y1,x2,y2 regex [0-9],[0-9],[0-9],[0-9]");
			m_inputString = Console.ReadLine();
			SubmitInput();
		}
		
        private bool TryParseInput() {
            bool isPatternMatch = Regex.IsMatch(m_inputString, c_inputPattern);
            if (!isPatternMatch) {
                return false;
            }

            string[] splitInput = m_inputString.Split(',');

            bool isParseFromX;
            bool isParseFromY;
            bool isParseToX;
            bool isParseToY;
            int fromX;
            int fromY;
            int toX;
            int toY;
            isParseFromX = int.TryParse(splitInput[0], out fromX);
            isParseFromY = int.TryParse(splitInput[1], out fromY);
            isParseToX = int.TryParse(splitInput[2], out toX);
            isParseToY = int.TryParse(splitInput[3], out toY);

            if (isParseFromX && isParseFromY && isParseToX && isParseToY) {
                m_fromPostion = new Vector2(fromX, fromY);
                m_toPosition = new Vector2(toX, toY);
                return true;
            }

            return false;
        }
		
        public void SubmitInput() {
            if (!TryParseInput()) {
                Console.WriteLine("Input needs to be from position and to position in the format x1,y1,x2,y2 regex [0-9],[0-9],[0-9],[0-9]");
                return;
            }

			Console.WriteLine("SubmitInput = "+m_inputString);
            m_gameController.ProcessTurn(m_fromPostion, m_toPosition);
        }
    }
}
