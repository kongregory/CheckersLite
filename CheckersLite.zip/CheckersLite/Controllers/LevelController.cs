﻿using System.Collections.Generic;

namespace CheckersLite {
    public class LevelController {
        public Vector2 m_grid { get; private set; }

        public Tile[,] tiles { get; private set; }

        public List<CharacterController> characters { get; private set; } = new List<CharacterController>();

        public LevelController(Vector2 grid) {
            m_grid = grid;

            int xTiles = (int)grid.x;
            int yTiles = (int)grid.y;
            tiles = new Tile[xTiles, yTiles];

            for (int i = 0; i < grid.x; i++) {
                for (int j = 0; j < grid.y; j++) {
                    tiles[i, j] = new Tile();
                }
            }
        }

        public void SpawnCharacter(CharacterController characterController) {
            characters.Add(characterController);
            int xPosition = (int)characterController.m_position.x;
            int yPosition = (int)characterController.m_position.y;
            tiles[xPosition, yPosition].characterController = characterController;
        }

        public void MoveCharacter(Vector2 fromPosition, Vector2 toPosition) {
            CharacterController characterController = GetCharacterController(fromPosition);
            tiles[fromPosition.x, fromPosition.y].characterController = null;
            characterController.UpdatePosition(toPosition);
            tiles[toPosition.x, toPosition.y].characterController = characterController;
        }

        private CharacterController GetCharacterController(Vector2 fromPosition) {
            return tiles[fromPosition.x, fromPosition.y].characterController;
        }

        public List<CharacterController> GetCharactersOfPlayer(int playerID) {
            List<CharacterController> playerCharacters = new List<CharacterController>();
            for(int i = 0; i< characters.Count; i++) {
                if(characters[i].m_playerID == playerID) {
                    playerCharacters.Add(characters[i]);
                }
            }
            return playerCharacters;
        }
    }

    public class Tile {
        public CharacterController characterController;
    }
}