﻿namespace CheckersLite {
    public class CharacterController {
        public int m_playerID { get; private set; } //the player who controls this character
        public Vector2 m_position { get; private set; }

        public bool isKing = false;

        public CharacterController(int playerID, Vector2 position) {
            m_playerID = playerID;
            m_position = position;
        }

        public void UpdatePosition(Vector2 newPosition) {
            m_position = new Vector2(newPosition.x, newPosition.y);
        }
    }
}