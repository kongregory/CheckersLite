﻿namespace CheckersLite {
    public class PlayerController {
        public PlayerDataModel m_playerDataModel { get; private set; }
        private LevelController m_levelController;

        public PlayerController(PlayerDataModel playerDataModel, LevelController levelController) {
            m_playerDataModel = playerDataModel;
            m_levelController = levelController;

            InitializeCharacters();
        }

        private void InitializeCharacters() {
            for (int i = 0; i < m_playerDataModel.numCharacters; i++) {
                Vector2 position = m_playerDataModel.characterPositions[i];
                CharacterController characterController = new CharacterController(m_playerDataModel.playerID, position);

                m_levelController.SpawnCharacter(characterController);
            }
        }
    }
}